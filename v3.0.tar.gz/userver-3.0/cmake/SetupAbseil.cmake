# userver does not use Abseil directly, but some libraries need it.

# @ingroup download
option(USERVER_DOWNLOAD_PACKAGE_ABSEIL "Download and setup Abseil if no Abseil matching version was found"
       ${USERVER_DOWNLOAD_PACKAGES}
)
# @ingroup download
option(USERVER_FORCE_DOWNLOAD_ABSEIL "Download Abseil even if it exists in a system" ${USERVER_DOWNLOAD_PACKAGES})

if(NOT USERVER_FORCE_DOWNLOAD_ABSEIL)
    set(ABSL_PROPAGATE_CXX_STD ON)

    if(USERVER_DOWNLOAD_PACKAGE_ABSEIL)
        find_package(absl QUIET)
    else()
        find_package(absl REQUIRED)
    endif()

    if(absl_FOUND)
        return()
    endif()
endif()

include(DownloadUsingCPM)

cpmaddpackage(
    NAME absl
    VERSION 20230802.1
    GIT_TAG 20230802.1
    GITHUB_REPOSITORY abseil/abseil-cpp
    GIT_SHALLOW TRUE
    SYSTEM
    PATCHES abseil_pr_1707.patch abseil_pr_1739.patch
    OPTIONS "ABSL_PROPAGATE_CXX_STD ON" "ABSL_ENABLE_INSTALL OFF"
)

mark_targets_as_system("${absl_SOURCE_DIR}")
write_package_stub(absl)
