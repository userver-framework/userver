include_guard(GLOBAL)

# @ingroup download
option(USERVER_DOWNLOAD_PACKAGE_ROCKS "Download and setup RocksDB if no RocksDB matching version was found"
       ${USERVER_DOWNLOAD_PACKAGES}
)

if(NOT USERVER_FORCE_DOWNLOAD_PACKAGES)
    if(USERVER_DOWNLOAD_PACKAGE_ROCKS)
        find_package(RocksDB QUIET CONFIG)
    else()
        find_package(RocksDB REQUIRED CONFIG)
    endif()

    if(RocksDB_FOUND)
        return()
    endif()
endif()

find_package(libgflags REQUIRED)
find_package(libsnappy REQUIRED)
find_package(ZLIB REQUIRED)
find_package(BZip2 REQUIRED)
find_package(zstd REQUIRED)

include(DownloadUsingCPM)

cpmaddpackage(
    NAME RocksDB
    GITHUB_REPOSITORY facebook/rocksdb
    GIT_TAG v10.4.2
    GIT_SHALLOW TRUE
    OPTIONS "ROCKSDB_BUILD_SHARED OFF"
            "WITH_SNAPPY ON"
            "WITH_BZ2 ON"
            "WITH_ZSTD ON"
            "WITH_TESTS OFF"
            "WITH_BENCHMARK_TOOLS OFF"
            "WITH_TOOLS OFF"
            "WITH_CORE_TOOLS OFF"
            "WITH_TRACE_TOOLS OFF"
            "USE_RTTI ON"
            "GFLAGS_SHARED FALSE"
            "CMAKE_SKIP_INSTALL_RULES ON"
)

mark_targets_as_system("${rocksdb_SOURCE_DIR}")
if(NOT TARGET RocksDB::rocksdb)
    add_library(RocksDB::rocksdb ALIAS rocksdb)
endif()
